function [Ygen,Igen] = Norton_gen(rp,xp,rm,xm,r0,x0,rn,xn,p,q,v,theta)

% rp : direct-sequence resistance (pu)
% xp : direct-sequence reactance  (pu)
% rm : negative-sequence resistance (pu)
% xm : negative-sequence reactance (pu)
% r0 : zero-sequence resistance (pu)
% x0 : zero-sequence reactance (pu)
% rn : neutral resistance (pu)
% xn : neutral reactance (pu)
%      set rn and xn to a very large value if neutral is not grounded
% p : active power produced by one phase of the generator (pu)
% q : reactive power produced by one phase of the generator (pu)
% v : voltage magnitude (pu), initial value in phase a
% theta : voltage phase angle (rad), initial value in phase a

% Ygen : 3x3 admittance matrix of generator
% Igen : 3x1 vector of Norton equivalent currents (INTO the network)

j= sqrt(-1) ;
a= exp(2*j*pi/3) ;
T= [ 1  1  1 ; a^2  a  1 ; a  a^2  1 ] ;

zp= rp+j*xp ;

YF= [ 1/zp    0        0                      ;
        0  1/(rm+j*xm) 0                      ;
        0     0     1/(r0+j*x0+3*(rn+j*xn)) ] ;
Ygen= T * YF * inv(T) ;

Va= v*exp(j*theta) ;
Ea= Va + zp*(p-j*q)/conj(Va) ;

Igen= [        Ea/zp   ;
       conj(a)*Ea/zp   ; 
             a*Ea/zp ] ;
end