function [Yld] = Yload(triangle,rn,xn,p,q,v)

% triangle= 1 if the load is assembled in triangle, =0 if assembled in star
% rn : neutral resistance (in pu), not used if triangle=1
% xn : neutral  reactance (in pu), not used if triangle=1
%      set rn and xn to a very large value if the neutral is not grounded
% p : active power (in pu) consumed: 
%           in one branch of the triangle (if triangle=1)
%           in one branch of the star (if triangle=0)
% q : reactive power (in pu) consumed: 
%           in one branch of the triangle (if triangle=1)
%           in one branch of the star (if triangle=0)
% v : magnitude of phase-to-neutral voltage (in pu) under which the above powers are consumed

% Yld : 3x3 admittance matrix of three-phase load

j=sqrt(-1) ;

if triangle
    y=(p-j*q)/(3*v^2) ;
    Yld= [  2*y   -y    -y   ;
            -y    2*y   -y   ;
            -y    -y    2*y ] ;
else
    y=(p-j*q)/v^2 ;
    if rn==0 && xn==0
        Yld= [ y   0   0   ;
               0   y   0   ;
               0   0   y ] ;
    else        
	    yn= 1/(rn+j*xn) ;
		ytot=3*y+yn ;
	    Yld = [ y-(y^2)/ytot  -(y^2)/ytot   -(y^2)/ytot    ;
                -(y^2)/ytot   y-(y^2)/ytot  -(y^2)/ytot    ;
				-(y^2)/ytot   -(y^2)/ytot   y-(y^2)/ytot ] ;
    end
end
end