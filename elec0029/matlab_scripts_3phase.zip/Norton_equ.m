function [Ynor,Inor] = Norton_equ(rth,xth,p,q,v,theta)

% rth : Th�venin equivalent resistance (in pu)
% xth : Th�venin equivalent  reactance (in pu)
% p :   active power produced by one phase (in pu)
% q : reactive power produced by one phase (in pu)
% v : magnitude of (phase-to-ground) voltage of phase a (pu)
% theta : phase angle of (phase-to-ground) voltage of phase a (rad)

% Ynor : 3x3 admittance matrix of Norton equivalent
% Inor : 3x1 vector of Norton currents

j=sqrt(-1) ;

zth= rth + j*xth ;

Ynor= [ 1/zth   0        0        ;
           0     1/zth   0        ;
           0        0     1/zth ] ;

Va= v*exp(j*theta) ;
Ea= Va + zth*(p-j*q)/conj(Va) ;       
Inor= [                Ea/zth   ;
        exp(-j*2*pi/3)*Ea/zth   ; 
        exp( j*2*pi/3)*Ea/zth ] ;
end