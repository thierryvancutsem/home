function [Ytf] = Ytrfo(rp,xp,bp,n,phi,b0,type,r0,x0,rn1,xn1,rn2,xn2)

% rp : positive-sequence series resistance (pu)
% xp : positive-sequence series reactance (pu)
% bp : positive-sequence magnetizing susceptance (pu)
% n  : magnitude of transformer ratio (pu/pu)
% phi : phase angle of transformer ratio (rad)
% b0 : zero-sequence magnetizing susceptance (pu)
% type = 1 indicates that the transformer is of the type Ynd
%      = 2 indicates that the transformer is of the type Ynyn
%      = 3 indicates that the transformer is of another type
%
% r0 : zero-sequence series resistance (pu); not used if type=3
% x0 : zero-sequence series  reactance (pu); not used if type=3
% rn1 : neutral resistance on the primary side (pu); not used if type=3
% xn1 : neutral  reactance on the primary side (pu); not used if type=3
% rn2 : neutral resistance on the secondary side (pu); not used if type=1 or 3
% xn2 : neutral  reactance on the secondary side (pu); not used if type=1 or 3
%
% set rn1 and xn1 (or rn2 and xn2) to very large values if neutral is not grounded

% Ytf : 6 x 6 admittance matrix of the transformer

j= sqrt(-1) ;
a= exp(2*j*pi/3) ;
T= [ 1  1  1 ; a^2  a  1 ; a  a^2  1 ] ;

yp= 1/(rp+j*xp) ;
ncplx= n*exp(j*phi) ;

if type == 1
    y0= 1/(r0+j*x0+3*(rn1+j*xn1)) ;
    Yzero= [ j*b0+y0  0 ; 0   0 ] ;
elseif type == 2
    y0= 1/(r0+j*x0+3*(rn1+j*xn1)+3*(rn2+j*xn2)/n^2) ;
    Yzero= [ j*b0+y0  -y0/n ; -y0/n   y0/n^2 ] ;
else
    Yzero= [ j*b0  0 ; 0   0 ] ;
end
    
YF=   [ j*bp+yp      0       0     -yp/ncplx  0        0      ;
           0       j*bp+yp   0       0   -yp/conj(ncplx)   0  ;
           0         0   Yzero(1,1)  0        0    Yzero(1,2) ;
    -yp/conj(ncplx)  0       0     yp/n^2     0        0      ;
           0   -yp/ncplx     0       0      yp/n^2     0      ;
           0         0   Yzero(2,1)  0        0    Yzero(2,2) ] ;

Ytf= [T zeros(3) ; zeros(3) T] * YF * [inv(T) zeros(3) ; zeros(3) inv(T)] ;

end
