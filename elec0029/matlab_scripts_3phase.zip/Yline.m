function [Yln] = Yline (rp,xp,bp,r0,x0,b0)

% rp : direct-sequence series resistance (pu)
% xp : direct-sequence series reactance (pu)
% bp : direct-sequence half shunt susceptance (pu)
% r0 : zero-sequence series resistance (pu)
% x0 : zero-sequence series reactance (pu)
% b0 : zero-sequence half shunt susceptance (pu)

% Yln : 6x6 admittance matrix of line

j=sqrt(-1) ;

zp= rp+j*xp ;
z0= r0+j*x0 ;

zs= (2*zp+z0)/3 ;
zm= (z0-zp)/3 ;
bs= (2*bp+b0)/3 ;
bm= (b0-bp)/3 ;

Z= [ zs zm zm   ; 
     zm zs zm   ; 
     zm zm zs ] ;
B= [ bs bm bm   ; 
     bm bs bm   ; 
     bm bm bs ] ;

Yln = [inv(Z)+j*B  -inv(Z) ; -inv(Z)  inv(Z)+j*B] ;
end
